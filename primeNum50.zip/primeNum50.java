public class primeNum50 {
	public static void main(String[] args) {
		int count=1;
		long check =2;
		boolean print=true;
		while (count<=50){
	    print =true;
		long d=check-1; 
		do {
			if (check !=2 && check%d ==0){
			print=false;
			break;
			}
			else d--;
		} while (d>1);
		if(print){
		System.out.print(" "+check);
		if (count%10==0)
		System.out.println("");
		count++;}
		 check++;
	    }
	}
}