import java.util.*;

public class GussBirthDay {
	public static void main(String[] args) {
	System.out.println("enter your name");
	Random input = new Random();
	Scanner input1= new Scanner (System.in);
	String name=input1.next();
	System.out.println("enter your last name");  
    String LName=input1.next();
	int day=input.nextInt(30);
	int month=input.nextInt(12);
	int year=input.nextInt(33)+1370;
	
	System.out.println("Mr/Ms "+name+" "+LName+" your birthday is :"+ year+"/"+month+"/"+day);
		
	}
}