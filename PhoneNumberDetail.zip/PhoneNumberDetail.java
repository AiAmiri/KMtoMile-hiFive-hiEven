import java.util.*;

public class PhoneNumber {
	public static void main(String[] args) {
	System.out.println("Welcome to identifier of your phone number");
    System.out.println("");
    System.out.println("Please enter your phone number ");
    Scanner input=new Scanner(System.in);
     String phoneNum=input.next();
     char x1=phoneNum.charAt(2);
 //    System.out.println(x1);
    if (phoneNum.length()==10 && phoneNum.startsWith("07") ) {
    	if (x1=='8' || x1=='3')
    	System.out.println("Etisalat");
    	else if (x1=='9' || x1=='2' )
    	System.out.println("Roshan");
    	else if (x1=='7' || x1=='6')
    	System.out.println("MTN");
    	else if (x1=='0' || x1=='1')
        System.out.println("AWCC");
        else if (x1=='4' || x1=='4')
        System.out.println("Salam");
        
        else System.out.println("not identified !!");
        }	
    else {System.out.println("invalid input or not from AFG !!");}
    	
	}
}