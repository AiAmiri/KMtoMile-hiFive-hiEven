import java.util.Scanner;
public class Main {
	public static void main(String[] args) {
		System.out.println("HiFive & HiEven checker");
		System.out.println("");
		System.out.println("enter an integer value");
		Scanner input = new Scanner(System.in);
		int x = input.nextInt();
		int y =x%2;
		int z =x%5;
		if (y==0 && z==0) System.out.println("hiFive and hiEven");
	    else if (y==0) System.out.println("hiEven");
		else if (z==0) System.out.println("hiFive");
		else System.out.println("none of them :( ");
	}
}