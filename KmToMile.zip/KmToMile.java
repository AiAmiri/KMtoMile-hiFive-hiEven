import java.util.Scanner;

public class Main {
	public static void main(String[] args) {
		System.out.println("  conveter fir KM to mile  ");
		System.out.println("");
		System.out.print("enter KM = ");
		double a;
		Scanner input = new Scanner (System.in);
		a = input.nextDouble();
		System.out.println("  ");
		System.out.print("it is = "+a*0.621371);
		System.out.println(" mile");;
	}
}