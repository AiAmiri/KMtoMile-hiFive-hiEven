import java.util.*;
public class Main {
	public static void main(String[] args) {
	System.out.println("welcome to lottery ");
	System.out.println("enter a number from 10 to 99");
	
	Scanner input=new Scanner(System.in);
	byte inpute=input.nextByte();
	String user=""+inpute;
	Random num=new Random();
	int rand=num.nextInt(90)+10;
	String Rand=""+rand;
	if (inpute<100 && inpute>9 ){
	if (user.equals(Rand))
	System.out.println("You are won 10000$");
	else if (user.charAt(0)==Rand.charAt(0) || user.charAt(1)==Rand.charAt(1))
	System.out.println("you are won 1000$");
	else if ( user.charAt(0)==Rand.charAt(1) && user.charAt(1)==Rand.charAt(0)  )
	System.out.println("you are won 3000$");
	else System.out.println("You are not winner");
	System.out.println("Random number was = "+Rand);}
	else System.out.println("invalid input");
	
	}
}