import java.util.*;
public class LoanPayment {
	public static void main(String[] args) {
	Scanner input= new Scanner(System.in);
	System.out.println("enter amount of loan ");
	double amount=input.nextDouble();
	System.out.println("enter year of loan ");
	double year=input.nextDouble();
	System.out.println("enter monthly interest rate ");
	double rate=input.nextDouble();
	rate =rate/100;
	double monthlyPay=amount*rate/1-1/Math.pow(1.0/1+rate,year*12);
    System.out.println("monthly pay = "+monthlyPay);
	double totalPay=year*12*rate*amount;
	System.out.println("total pay = "+totalPay);
	}
}