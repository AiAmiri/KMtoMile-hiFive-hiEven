public class ShapeTringle {
	public static void main(String[] args) {
		int x=1;
		String triangle="+ ";
		do {
			System.out.println(triangle);
			triangle =triangle+"+ ";
			x++;
		}while(x<=20); //x=lenght & hight
		
		System.out.println("");
		
		int b=1;
		int d=20; //d=hight
		do{	
			for (int c=1; c<=d; c++){
			System.out.print("* ");
			}
			d--;
			System.out.println("");
			b++;
		} while (b<=20); // b=lenght
		
		System.out.println("");	
		
	    int t=20; //t=lenght
        int e=0;
        do {
        while (t>0){
        System.out.print("* ");
        t--;		
        }
        System.out.println("");
        t=20; //t=lenght
        e++;
        } while(e<20); //e=hight
		
	}
}