import java.util.Scanner;
public class MonetaryUnits {
	public static void main(String[] args) {
	System.out.println("enter amount of dollars in decimals");
	Scanner input = new Scanner (System.in);
	double amount=input.nextDouble();
	System.out.println("in Single dollars = "+ (int)amount);
	System.out.println("in quarters = "+ (int)amount*4);
	System.out.println("in dimes = "+ (int)amount*10);
	System.out.println("in nickels = "+ (int)amount*20);
	System.out.println("in pennies = "+ (int)amount*100);
	}
}