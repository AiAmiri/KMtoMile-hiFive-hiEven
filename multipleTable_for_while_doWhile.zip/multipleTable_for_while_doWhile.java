public class MultiplacationTable_for_whil_doWhile {
	public static void main(String[] args) {
	
//for
	for (int x=1; x<=10 ;x++){
	 for (int y=1; y<=10; y++){
	 System.out.print(y+"×"+x+"="+y*x+"  ");
	  }
	 System.out.println("\n");
	 }
	 
//while
	 byte x=1;
	 byte y=1;
	 while (x<=10){
	   while (y<=10){
	   System.out.print(y+"×"+x+"="+y*x+"  "); 
	   y++;
		}
	   x++;
	   y-=10;
	   System.out.println("\n");
	}
	
//di_while
	int a=1;
	int b=1;
	do {
	  do{
	  System.out.print(a+"×"+b+"="+b*a+"  ");
	  a++;
	  }while (a<=10);
	  System.out.println("\n");
	  a-=10;
	  b++;
	} while (b<=10);
		
	}
}